package com.example.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component
public class Traveller2 {
	private Vehicle obj=null;
	@Autowired
	public Traveller2(@Qualifier("car")Vehicle t)
	{
		super();
		this.obj = t;
	}
	public void startJourney()
	{
	this.obj.move();
		
	}

}
