package com.example.springcoredemo;

public interface Vehicle {
	public void move();

}
