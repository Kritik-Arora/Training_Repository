package com.example.springcoredemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client2 {
	public static void main(String args[])
	{
		
	AnnotationConfigApplicationContext appl = new AnnotationConfigApplicationContext(AppConfig2.class);
		Traveller2 obj = appl.getBean(Traveller2.class);
		obj.startJourney();
	
	
	
	}

}
