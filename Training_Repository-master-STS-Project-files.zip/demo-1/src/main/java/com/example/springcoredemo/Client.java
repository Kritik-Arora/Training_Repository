package com.example.springcoredemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Client {
public static void main(String args[])
{   /*Bike bike =  new Bike();
	Car car = new Car();
	Traveller1 obj = new Traveller1(bike);
	obj.startJourney();*/
	
AnnotationConfigApplicationContext appl = new AnnotationConfigApplicationContext(AppConfig.class);
Car obj = appl.getBean(Car.class);
obj.move();

	
}
}
