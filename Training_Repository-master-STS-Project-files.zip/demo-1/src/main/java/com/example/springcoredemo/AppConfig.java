package com.example.springcoredemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    Vehicle returnCarObj()
	{
		return new Car();
	}

    @Bean
    Vehicle returnBikeObj()
	{
		return new Bike();
	}
	public Traveller1 returnTravellerObj()
	{
		return new Traveller1(returnBikeObj()); //Dependency Injection
	}
}
