package com.example.springcoredemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("car")
public class Car implements Vehicle{
	public void move()
	{
		System.out.println("Car is moving");
	}

}
