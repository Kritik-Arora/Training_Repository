package com.example.springcoredemo;

public class Traveller1  {
	private Vehicle vehicle;
	public Traveller1(Vehicle vehicle)
	{
		this.vehicle = vehicle;
	}
	public void startJourney()
	{
	this.vehicle.move();
		
	}


}
