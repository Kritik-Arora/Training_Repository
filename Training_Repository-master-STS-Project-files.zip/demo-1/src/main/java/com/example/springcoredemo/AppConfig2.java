package com.example.springcoredemo;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.example.springcoredemo")
public class AppConfig2 {

}
