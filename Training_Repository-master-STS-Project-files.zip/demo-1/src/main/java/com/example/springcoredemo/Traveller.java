package com.example.springcoredemo;

public class Traveller {
	private Car carObj = null;
	public Traveller()
	{
		super();
		this.carObj = new Car();
	}
	public void startJourney()
	{
		this.carObj.move();
	}

}
