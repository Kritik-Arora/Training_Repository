package com.example.springcoredemo;

import org.springframework.stereotype.Component;

@Component("sms")
public class SmsService implements IMessage{
	@Override
	public void sendMessage() {
		System.out.println("Sms is sent");
		
	}

}
