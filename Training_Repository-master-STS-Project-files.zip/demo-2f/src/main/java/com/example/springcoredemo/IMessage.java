package com.example.springcoredemo;

public interface IMessage {
	public void sendMessage();

}
