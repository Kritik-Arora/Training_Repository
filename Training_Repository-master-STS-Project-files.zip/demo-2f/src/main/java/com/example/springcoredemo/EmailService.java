package com.example.springcoredemo;

import org.springframework.stereotype.Component;

@Component("email")
public class EmailService implements IMessage{
	@Override
	public void sendMessage() {
		System.out.println("Email is sent");
		
	}

}
