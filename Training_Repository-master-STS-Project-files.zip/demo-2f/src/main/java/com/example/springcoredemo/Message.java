package com.example.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
@Component("message")
public class Message {
	private IMessage smsMessage;
    private IMessage emailMessage;

    @Autowired
    public Message(@Qualifier("sms") IMessage smsMessage, @Qualifier("email") IMessage emailMessage) {
        this.smsMessage = smsMessage;
        this.emailMessage = emailMessage;
    }

    public void sendMessages(String messageType) {
        if ("sms".equals(messageType)) {
            System.out.println("Sending SMS....");
            smsMessage.sendMessage();
        } else if ("email".equals(messageType)) {
            System.out.println("Sending Email....");
            emailMessage.sendMessage();
        } else {
            System.out.println("Unsupported message type: " + messageType);
        }
    }
}
