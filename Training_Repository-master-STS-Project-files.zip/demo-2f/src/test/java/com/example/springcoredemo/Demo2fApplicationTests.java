package com.example.springcoredemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demo2fApplicationTests {

	@Test
	void contextLoads() {
	}

}
