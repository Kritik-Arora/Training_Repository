package com.example.springcoredemo;

public interface DataSource {
	 void connect();
}
