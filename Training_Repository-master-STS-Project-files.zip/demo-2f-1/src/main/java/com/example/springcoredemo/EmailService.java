package com.example.springcoredemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class EmailService {
	private final DataSource dataSource;

    @Autowired
    public EmailService(@Qualifier("mysql")  DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // Method to send an email
    public void sendEmail(String to, String subject, String body) {
        dataSource.connect();
        // Implement email sending logic here
        System.out.println("Email sent to " + to + " with subject: " + subject + " and body: " + body);
    }

    // Method to return the connection information
    public void returnConnection() {
        dataSource.connect();
    }

}
