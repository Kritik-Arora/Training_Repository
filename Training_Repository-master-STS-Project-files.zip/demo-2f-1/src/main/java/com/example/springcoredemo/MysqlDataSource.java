package com.example.springcoredemo;

import org.springframework.stereotype.Component;

@Component("mysql")
public class MysqlDataSource implements DataSource{
	 @Override
	    public void connect() {
	        System.out.println("Connected to MySQL data source");
	    }

}
