package com.example.springcoredemo;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class Client {
	private final EmailService emailService;

    public Client(EmailService emailService) {
        this.emailService = emailService;
    }

    // Method to use the email service
    public void useEmailService() {
        emailService.sendEmail("kritik@example.com", "annotations demonstration", "Hello, this is a kritik's annotation test email!");
    }
    public static void main(String[] args) {
        // Create a Spring application context using Java configuration
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        // Retrieve the Client bean from the context
        Client client = context.getBean(Client.class);

        
        client.useEmailService();

        // Close the application context
        context.close();
    }
}
