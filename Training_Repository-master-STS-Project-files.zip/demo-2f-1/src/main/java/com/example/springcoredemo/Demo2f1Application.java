package com.example.springcoredemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo2f1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demo2f1Application.class, args);
	}

}
