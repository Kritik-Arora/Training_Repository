package com.example.springcoredemo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component("portgres")
@Primary
public class PostgresDataSource implements DataSource{
	@Override
    public void connect() {
        System.out.println("Connected to PostgreSQL data source");
    }

}
